<?php
// ����
include_once(dirname(__FILE__).'/../include/common.inc.php');

// �Ƿ����ƶ���
function app4wap(){
	if(isset($_SERVER['HTTP_X_WAP_PROFILE'])){
		return true;
	}
	if(isset($_SERVER['HTTP_CLIENT']) && 'PhoneClient' == $_SERVER['HTTP_CLIENT']){
		return true;
	}
	if(stristr($_SERVER['HTTP_VIA'],'wap')){
		return true;
	}
	if(isset($_SERVER['HTTP_USER_AGENT'])){
		$clientkeywords=array('nokia','sony','ericsson','mot','samsung','htc','sgh','lg','sharp','sie-','philips','panasonic','alcatel','lenovo','iphone','ipod','blackberry','meizu','android','netfront','symbian','ucweb','windowsce','palm','operamini','operamobi','openwave','nexusone','cldc','uidp','wap','mobile',);
		if(preg_match("/(" . implode('|',$clientkeywords) . ")/i",strtolower($_SERVER['HTTP_USER_AGENT']))){
			return true;
	}
	}
	if(isset($_SERVER['HTTP_ACCEPT'])){
		if((strpos($_SERVER['HTTP_ACCEPT'],'vnd.wap.wml') !== false) && (strpos($_SERVER['HTTP_ACCEPT'],'text/html') === false || (strpos($_SERVER['HTTP_ACCEPT'],'vnd.wap.wml')<strpos($_SERVER['HTTP_ACCEPT'],'text/html')))){
			return true;
	}
	}
	return false;
}

if(app4wap()){
	$templets='wap.html';
}else{
	$templets='pc.html';
}

$arr=scandir(dirname(__FILE__));
foreach($arr as $k => $v){
	if(strstr($v,'.apk')){
		$apk=$v;
		break;
	}
}

if(!$apk){
	$noapp='<div class="noapp">��δ����app�����ҿͷ��˽�<br>�ͷ�QQ��1981255858</div>';
}

include_once(DEDEINC.'/datalistcp.class.php');
$dlist = new DataListCP();
$dlist->SetTemplet('templets/'.$templets);
$dlist->Display();
?>